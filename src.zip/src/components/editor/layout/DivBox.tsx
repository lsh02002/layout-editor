import {
  useCallback,
  useRef,
  useState,
  type HTMLAttributes,
  type MouseEvent,
  type MouseEventHandler,
  type PointerEvent,
  type ReactNode,
} from "react";

import EditMenuBox from "./EditMenuBox";

import type { ComponentLayout } from "../../../types/types";

interface DivBoxProps extends HTMLAttributes<HTMLDivElement> {
  children?: ReactNode;
  previewMode?: boolean;
  layout?: ComponentLayout;
  positionContextId?: string | null;
  onLayoutChange?: (
    layout: Partial<ComponentLayout>,
    recordHistory?: boolean,
  ) => void;
  onSelect?: () => void;
  onEdit?: () => void;
  onCopy?: () => void;
  onDelete?: () => void;
  onToolbarVisibleChange?: (visible: boolean) => void;
  snapLayout: (layout: Partial<ComponentLayout>) => Partial<ComponentLayout>;
}

type PositionDragState = {
  pointerId: number;
  startX: number;
  startY: number;
  originalX: number;
  originalY: number;
  currentX: number;
  currentY: number;
};

function DivBox({
  children,
  previewMode = false,
  layout,
  positionContextId,
  onLayoutChange,
  onSelect,
  onEdit,
  onCopy,
  onDelete,
  onToolbarVisibleChange,
  snapLayout,
  className = "",
  style,
}: DivBoxProps) {
  const [over, setOver] = useState(false);
  const [moving, setMoving] = useState(false);
  const positionDragRef = useRef<PositionDragState | null>(null);
  const positionElementRef = useRef<HTMLElement | null>(null);
  const isAbsolute = layout?.position === "absolute";

  const isOwnDivBox = (
    target: EventTarget | null,
    currentTarget: HTMLElement,
  ) => {
    const element = target as HTMLElement | null;

    if (!element) {
      return false;
    }
    const closestDivBox = element.closest<HTMLElement>("[data-layout-box]");

    return closestDivBox === currentTarget;
  };

  const handleMouseMove: MouseEventHandler<HTMLDivElement> = (event) => {
    if (previewMode) {
      return;
    }

    const target = event.target as HTMLElement;
    const closestDivBox = target.closest("[data-layout-box]");
    setOver(closestDivBox === event.currentTarget);
    onToolbarVisibleChange?.(closestDivBox === event.currentTarget);
  };

  const handleMouseLeave: MouseEventHandler<HTMLDivElement> = () => {
    setOver(false);
    onToolbarVisibleChange?.(false);
  };

  const handleClick = useCallback(
    (event: MouseEvent<HTMLDivElement>) => {
      if (previewMode) {
        return;
      }

      if (!isOwnDivBox(event.target, event.currentTarget)) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      onSelect?.();
    },
    [onSelect, previewMode],
  );

  const handleEdit = useCallback(
    (event: MouseEvent<HTMLButtonElement>) => {
      event.stopPropagation();

      if (previewMode) {
        return;
      }
      onEdit?.();
    },
    [onEdit, previewMode],
  );

  const handleCopy = useCallback(
    (event: MouseEvent<HTMLButtonElement>) => {
      event.stopPropagation();

      if (previewMode) {
        return;
      }
      onCopy?.();
    },
    [onCopy, previewMode],
  );

  const handleDelete = useCallback(
    (event: MouseEvent<HTMLButtonElement>) => {
      event.stopPropagation();

      if (previewMode) {
        return;
      }

      onDelete?.();
    },
    [onDelete, previewMode],
  );

  const handlePositionPointerDown = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      if (previewMode || !isAbsolute || !onLayoutChange) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      event.currentTarget.setPointerCapture(event.pointerId);

      const x = layout?.x ?? 0;
      const y = layout?.y ?? 0;

      const layoutBox =
        event.currentTarget.closest<HTMLElement>("[data-layout-box]");

      positionElementRef.current = layoutBox?.parentElement ?? null;

      positionDragRef.current = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originalX: x,
        originalY: y,
        currentX: x,
        currentY: y,
      };

      setMoving(true);
    },
    [isAbsolute, layout?.x, layout?.y, onLayoutChange, previewMode],
  );

  const handlePositionPointerMove = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      const drag = positionDragRef.current;

      if (!drag || drag.pointerId !== event.pointerId) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      const deltaX = event.clientX - drag.startX;
      const deltaY = event.clientY - drag.startY;

      const rawX = drag.originalX + deltaX;
      const rawY = drag.originalY + deltaY;

      const snapped = snapLayout({
        x: rawX,
        y: rawY,
      }) ?? {
        x: rawX,
        y: rawY,
      };

      const x = typeof snapped.x === "number" ? snapped.x : rawX;
      const y = typeof snapped.y === "number" ? snapped.y : rawY;

      drag.currentX = x;
      drag.currentY = y;

      const element = positionElementRef.current;

      if (element) {
        element.style.left = `${x}px`;
        element.style.top = `${y}px`;
      }
    },
    [snapLayout],
  );

  const handlePositionPointerUp = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      const drag = positionDragRef.current;

      if (!drag || drag.pointerId !== event.pointerId) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();

      if (event.currentTarget.hasPointerCapture(event.pointerId)) {
        event.currentTarget.releasePointerCapture(event.pointerId);
      }

      onLayoutChange?.(
        {
          x: drag.currentX,
          y: drag.currentY,
        },
        true,
      );

      positionDragRef.current = null;
      positionElementRef.current = null;
      setMoving(false);
    },
    [onLayoutChange],
  );

  const handlePositionPointerCancel = useCallback(
    (event: PointerEvent<HTMLButtonElement>) => {
      const drag = positionDragRef.current;

      event.stopPropagation();

      if (!drag || drag.pointerId !== event.pointerId) {
        return;
      }

      if (event.currentTarget.hasPointerCapture(event.pointerId)) {
        event.currentTarget.releasePointerCapture(event.pointerId);
      }

      const element = positionElementRef.current;

      if (element) {
        element.style.left = `${drag.originalX}px`;
        element.style.top = `${drag.originalY}px`;
      }

      positionDragRef.current = null;
      positionElementRef.current = null;
      setMoving(false);
    },
    [],
  );

  const handlePointerUp = useCallback(
    (event: PointerEvent<HTMLDivElement>) => {
      if (event.pointerType === "mouse") {
        return;
      }

      if (previewMode) {
        return;
      }

      event.stopPropagation();
      if (!isOwnDivBox(event.target, event.currentTarget)) {
        return;
      }

      onSelect?.();
    },
    [onSelect, previewMode],
  );

  return (
    <div
      data-layout-box
      data-position-context-id={positionContextId}
      className={`
        d-inline-block
        ${className}        
      `}
      onClick={handleClick}
      onPointerUp={handlePointerUp}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        width: layout?.width ?? (isAbsolute ? "max-content" : undefined),
        maxWidth: isAbsolute ? "none" : undefined,
        height: layout?.height,
        ...style,
        position: "relative",
        outline:
          style?.outline ??
          (!previewMode && over
            ? "1px solid #6f42c1"
            : "1px solid transparent"),
        outlineOffset:
          style?.outlineOffset ?? (!previewMode && over ? "-1px" : undefined),
      }}
    >
      {!previewMode && isAbsolute && (
        <button
          type="button"
          draggable={false}
          className="
              btn
              btn-light
              btn-sm
              rounded-circle
            "
          style={{
            position: "absolute",
            left: -40,
            top: 0,
            width: 32,
            height: 32,
            minWidth: 32,
            minHeight: 32,
            padding: 0,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            cursor: moving ? "grabbing" : "move",
            touchAction: "none",
            userSelect: "none",
            WebkitUserSelect: "none",
            border: "1px solid #cbd5e1",
            color: "#64748b",
            background: "#fff",
            boxShadow: "0 2px 8px rgba(15,23,42,.10)",
            zIndex: 110,
          }}
          onDragStart={(event) => {
            event.preventDefault();
            event.stopPropagation();
          }}
          onPointerDown={handlePositionPointerDown}
          onPointerMove={handlePositionPointerMove}
          onPointerUp={handlePositionPointerUp}
          onPointerCancel={handlePositionPointerCancel}
          onClick={(event) => {
            event.preventDefault();
            event.stopPropagation();
          }}
          title="자유 위치 이동"
          aria-label="자유 위치 이동"
        >
          ✥
        </button>
      )}
      {!previewMode && over && (
        <div
          data-edit-menu
          className="
              position-absolute
              end-0
              text-white
            "
          style={{
            top: 0,
            transform: "translateY(-100%)",
            background: "#6f42c1",
            padding: "2px 8px",
            borderRadius: "6px 6px 0 0",
            whiteSpace: "nowrap",
            zIndex: 100,
          }}
        >
          <EditMenuBox
            onEdit={handleEdit}
            onCopy={handleCopy}
            onDelete={handleDelete}
          />
        </div>
      )}

      {children}
    </div>
  );
}

export default DivBox;
